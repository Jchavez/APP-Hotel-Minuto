package com.hotelm.clases;

public class Cities 
{
	private String cities;
	
	public Cities(String cities)
	{
	   this.cities = cities;
	  
	}

	public String getCities(){
		return cities;
	}
	
	public void setCities(String cita) {
	      this.cities = cita;
	}
	
	

}

package com.hotelm.utils;

public interface Item {

    public boolean isSection();

}
